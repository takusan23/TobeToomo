function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がRPGアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.message.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.loaded.add(function () {
          var currentTickCount = 0;
          scene.update.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 2
    }],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["intai", "inu", "kanemoti", "karaoke_2", "karaoke", "kiyomizu", "korean", "launch", "n_kou", "result", // tslint:disable-next-line: max-line-length
          "doumo_toomo", "gogo_no_zyugyou", "hattastu_syougai", "karaoke_ikuka", "katsudon_channel", "korean_sound", "n_kou_taigaku", "san_ryuunen", "teacher_block"]
        });
        var time = 60; // 制限時間

        if (param.sessionParameter.totalTimeLimit) {
          time = param.sessionParameter.totalTimeLimit; // セッションパラメータで制限時間が指定されたらその値を使用します
        } // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います


        g.game.vars.gameState = {
          score: 0
        }; // タイトル画面

        var titleScene = new g.Scene({
          game: g.game,
          assetIds: ["title"]
        });
        titleScene.loaded.add(function () {
          // 読み込み成功
          // タイトル画面出す
          var titleSprite = new g.Sprite({
            scene: titleScene,
            src: titleScene.assets["title"]
          }); // 追加

          titleScene.append(titleSprite); // 5秒待つ

          titleScene.setTimeout(function () {
            scene.loaded.add(function () {
              // 5秒引く
              time -= 5; // ここからゲーム内容を記述します
              // 背景用意

              var backgroundFilledRect = new g.FilledRect({
                scene: scene,
                width: g.game.width,
                height: g.game.height,
                cssColor: "white"
              });
              scene.append(backgroundFilledRect); // フォントの生成

              var font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.SansSerif,
                size: 48
              }); // スコア表示用のラベル

              var scoreLabel = new g.Label({
                scene: scene,
                text: "スコア: 0",
                font: font,
                fontSize: font.size / 2,
                textColor: "black"
              });
              scene.append(scoreLabel); // 残り時間表示用ラベル

              var timeLabel = new g.Label({
                scene: scene,
                text: "残り時間: 0",
                font: font,
                fontSize: font.size / 2,
                textColor: "black",
                x: 0.7 * g.game.width
              });
              scene.append(timeLabel); // プレイヤー画像

              var playerSprite = new g.Sprite({
                scene: scene,
                src: scene.assets["inu"]
              });
              playerSprite.x = 100;
              playerSprite.y = 200;
              playerSprite.modified();
              scene.append(playerSprite); // 地面

              var groundFilledRect = new g.FilledRect({
                scene: scene,
                width: g.game.width,
                height: 20,
                cssColor: "black"
              });
              groundFilledRect.y = playerSprite.y + playerSprite.height; // 地面の高さ

              groundFilledRect.modified();
              scene.append(groundFilledRect); // 音の名前の配列

              var soundList = ["doumo_toomo", "gogo_no_zyugyou", "hattastu_syougai", "karaoke_ikuka", "katsudon_channel", "korean_sound", "n_kou_taigaku", "san_ryuunen", "teacher_block"]; // ジャンプする
              // 連打対策

              var isJump = true;
              scene.pointDownCapture.add(function () {
                if (isJump) {
                  // 音発生！
                  var soundRandom = g.game.random.get(0, soundList.length - 1);
                  scene.assets[soundList[soundRandom]].play(); // 押せなくする

                  isJump = false; // 計算に必要な奴

                  var v0_1 = 15;
                  var gravity_1 = 0.9;
                  var ground_1 = 210;
                  var jumpTime_1 = 0; // 計算する

                  var jumpUpdateFanc_1 = function jumpUpdateFanc_1() {
                    // 公式
                    var calc = 0.5 * gravity_1 * jumpTime_1 * jumpTime_1 - v0_1 * jumpTime_1 + ground_1;

                    if (calc <= ground_1) {
                      // ジャンプ中
                      playerSprite.y = calc;
                    } else {
                      playerSprite.update.remove(jumpUpdateFanc_1);
                      isJump = true;
                    }

                    jumpTime_1++;
                    playerSprite.modified();
                  };

                  playerSprite.update.add(jumpUpdateFanc_1);
                }
              }); // 障害物？作成
              // 使う画像の名前の配列

              var imgList = ["intai", "kanemoti", "karaoke_2", "karaoke", "kiyomizu", "korean", "launch", "n_kou"]; // 定期実行

              scene.setInterval(function () {
                // 生成も少しずらす
                var timeoutRandom = g.game.random.get(500, 1000);
                scene.setTimeout(function () {
                  // 画像はらんだむ
                  var random = g.game.random.get(0, imgList.length - 1);
                  var obj = new g.Sprite({
                    scene: scene,
                    src: scene.assets[imgList[random]]
                  }); // いち

                  obj.x = g.game.width + obj.width;
                  obj.y = groundFilledRect.y - obj.height; // 動かす

                  obj.update.add(function () {
                    // 時間内なら
                    if (time >= 5) {
                      obj.x -= 10;
                      obj.modified(); // 当たったら

                      if (g.Collision.intersectAreas(obj, playerSprite)) {
                        // 消す＋減点
                        obj.destroy();
                        g.game.vars.gameState.score -= 50; // テキスト反映

                        scoreLabel.text = "\u30B9\u30B3\u30A2: " + g.game.vars.gameState.score;
                        scoreLabel.invalidate();
                      }
                    }
                  });
                  scene.append(obj);
                }, timeoutRandom);
              }, 1500); // 進んだら点数あっぷ

              scene.update.add(function () {
                // 時間内なら
                if (time >= 5) {
                  g.game.vars.gameState.score++; // テキスト反映

                  scoreLabel.text = "\u30B9\u30B3\u30A2: " + g.game.vars.gameState.score;
                  scoreLabel.invalidate();
                }
              });

              var updateHandler = function updateHandler() {
                if (time <= 0) {
                  // RPGアツマール環境であればランキングを表示します
                  if (param.isAtsumaru) {
                    var boardId_1 = 1;
                    window.RPGAtsumaru.experimental.scoreboards.setRecord(boardId_1, g.game.vars.gameState.score).then(function () {
                      window.RPGAtsumaru.experimental.scoreboards.display(boardId_1);
                    });
                  }

                  scene.update.remove(updateHandler); // カウントダウンを止めるためにこのイベントハンドラを削除します
                } // 終了画面


                if (time <= 5) {
                  var resultSprite = new g.Sprite({
                    scene: scene,
                    src: scene.assets["result"]
                  });
                  scene.append(resultSprite);
                } // カウントダウン処理


                time -= 1 / g.game.fps;
                timeLabel.text = "残り時間: " + Math.ceil(time - 5) + " 秒";
                timeLabel.invalidate();
              };

              scene.update.add(updateHandler); // ここまでゲーム内容を記述します
            });
            g.game.pushScene(scene);
          }, 5000);
        }); // シーン切り替え

        g.game.pushScene(titleScene);
      }

      exports.main = main;
    }, {}]
  }, {}, [1])(1);
});