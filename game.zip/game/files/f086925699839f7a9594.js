function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がRPGアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.message.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.loaded.add(function () {
          var currentTickCount = 0;
          scene.update.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 2
    }],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["inu", "n_kou", "result", "intai"]
        });
        var time = 70; // 制限時間

        if (param.sessionParameter.totalTimeLimit) {
          time = param.sessionParameter.totalTimeLimit; // セッションパラメータで制限時間が指定されたらその値を使用します
        } // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います


        g.game.vars.gameState = {
          score: 0
        }; // タイトル画面

        var titleScene = new g.Scene({
          game: g.game,
          assetIds: ["title"]
        });
        titleScene.loaded.add(function () {
          // タイトル画像
          var titleSprite = new g.Sprite({
            scene: titleScene,
            src: titleScene.assets["title"]
          }); // タイトル画像追加

          titleScene.append(titleSprite); // 読み込み成功時

          titleScene.setTimeout(function () {
            // 5秒経ったらゲーム開始。
            time -= 5;
            scene.loaded.add(function () {
              // ここからゲーム内容を記述します
              // 背景用意
              var backgroundFilledRect = new g.FilledRect({
                scene: scene,
                width: g.game.width,
                height: g.game.height,
                cssColor: "white"
              });
              scene.append(backgroundFilledRect); // フォントの生成

              var font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.SansSerif,
                size: 48
              }); // スコア表示用のラベル

              var scoreLabel = new g.Label({
                scene: scene,
                text: "スコア: 0",
                font: font,
                fontSize: font.size / 2,
                textColor: "black"
              });
              scene.append(scoreLabel); // 残り時間表示用ラベル

              var timeLabel = new g.Label({
                scene: scene,
                text: "時間: 70",
                font: font,
                fontSize: font.size / 2,
                textColor: "black",
                x: 0.7 * g.game.width
              });
              scene.append(timeLabel); // プレイヤーの表示

              var playerSprite = new g.Sprite({
                scene: scene,
                src: scene.assets["inu"],
                y: 200,
                x: 100
              });
              scene.append(playerSprite); // 地面

              var groundFilledRect = new g.FilledRect({
                scene: scene,
                width: g.game.width,
                height: 20,
                cssColor: "black",
                y: playerSprite.y + playerSprite.height // プレイヤーの下にいるように

              });
              scene.append(groundFilledRect); // 物理の授業。
              // 押したらジャンプできるようにする。
              // 連打対策

              var isJump = true; // ジャンプ可能ならtrue

              scene.pointDownCapture.add(function () {
                if (isJump) {
                  isJump = false; // 計算に必要なもの

                  var v0_1 = 15; // 初速度

                  var gravity_1 = 0.9; // 重力加速度

                  var ground_1 = 210; // 地面の位置

                  var jumpTime_1 = 0; // 時間
                  // 毎フレーム呼ばれる関数

                  var jumpUpdateFanc_1 = function jumpUpdateFanc_1() {
                    // 公式
                    var calc = 0.5 * gravity_1 * jumpTime_1 * jumpTime_1 - v0_1 * jumpTime_1 + ground_1;

                    if (calc <= ground_1) {
                      // ジャンプ中
                      playerSprite.y = calc;
                    } else {
                      // 着地
                      playerSprite.update.remove(jumpUpdateFanc_1); // 毎フレーム呼ばれる関数解除

                      isJump = true; // ジャンプできるようにする
                    }

                    jumpTime_1 += 1;
                    playerSprite.modified();
                  };

                  playerSprite.update.add(jumpUpdateFanc_1); // 毎フレーム呼ばれる関数登録
                }
              }); // 障害物作成

              scene.setInterval(function () {
                if (time >= 5) {
                  // 時間内
                  // ちょっとランダム
                  var timeRandom = g.game.random.get(500, 1000);
                  scene.setTimeout(function () {
                    var nKouSprite = new g.Sprite({
                      scene: scene,
                      src: scene.assets["n_kou"]
                    }); // 位置

                    nKouSprite.y = groundFilledRect.y - nKouSprite.height;
                    nKouSprite.x = g.game.width + nKouSprite.width; // 動かす

                    nKouSprite.update.add(function () {
                      if (time >= 5) {
                        nKouSprite.x -= 10;
                        nKouSprite.modified(); // 当たり判定

                        if (g.Collision.intersectAreas(nKouSprite, playerSprite)) {
                          // 当たったら消して減点！
                          nKouSprite.destroy();
                          g.game.vars.gameState.score -= 50;
                          scoreLabel.text = "\u30B9\u30B3\u30A2: " + g.game.vars.gameState.score;
                          scoreLabel.invalidate(); // 再描画
                        }
                      }
                    });
                    scene.append(nKouSprite);
                  }, timeRandom);
                }
              }, 1500); // // おまけ。得点要素も
              // scene.setInterval(() => {
              // 	// ランダムで出すか決定
              // 	const random = g.game.random.get(1, 5);
              // 	if (random === 5) {
              // 		const intaiSprite = new g.Sprite({
              // 			scene: scene,
              // 			src: scene.assets["intai"]
              // 		});
              // 		intaiSprite.x = (g.game.width + intaiSprite.width);
              // 		intaiSprite.y = g.game.random.get(50, 200); // 高さはランダム
              // 		intaiSprite.update.add(() => {
              // 			if (time >= 5) {
              // 				intaiSprite.x -= 10;
              // 				intaiSprite.modified();
              // 				// 当たり判定
              // 				if (g.Collision.intersectAreas(intaiSprite, playerSprite)) {
              // 					// 当たったら消して点数入れる！
              // 					intaiSprite.destroy();
              // 					g.game.vars.gameState.score += 500;
              // 					scoreLabel.text = `スコア: ${g.game.vars.gameState.score}`;
              // 					scoreLabel.invalidate(); // 再描画
              // 				}
              // 			}
              // 		});
              // 		scene.append(intaiSprite);
              // 	}
              // }, 1000);
              // 進んだら点数を加算。

              playerSprite.update.add(function () {
                // スコア
                g.game.vars.gameState.score += 1; // スコアテキスト反映

                scoreLabel.text = "\u30B9\u30B3\u30A2: " + g.game.vars.gameState.score;
                scoreLabel.invalidate(); // 再描画
              });

              var updateHandler = function updateHandler() {
                if (time <= 0) {
                  // RPGアツマール環境であればランキングを表示します
                  if (param.isAtsumaru) {
                    var boardId_1 = 1;
                    window.RPGAtsumaru.experimental.scoreboards.setRecord(boardId_1, g.game.vars.gameState.score).then(function () {
                      window.RPGAtsumaru.experimental.scoreboards.display(boardId_1);
                    });
                  }

                  scene.update.remove(updateHandler); // カウントダウンを止めるためにこのイベントハンドラを削除します
                } // ゲーム終了


                if (time <= 5) {
                  // 終了画面
                  var resultSprite = new g.Sprite({
                    scene: scene,
                    src: scene.assets["result"]
                  });
                  scene.append(resultSprite); // 押せなくする

                  scene.pointDownCapture.removeAll();
                  playerSprite.update.removeAll();
                } // カウントダウン処理


                time -= 1 / g.game.fps;
                timeLabel.text = "残り時間: " + Math.ceil(time - 5) + " 秒"; // 最後の5秒は終了画面のために使う。

                timeLabel.invalidate();
              };

              scene.update.add(updateHandler); // ここまでゲーム内容を記述します
            });
            g.game.pushScene(scene);
          }, 5000);
        }); // 画面切り替え

        g.game.pushScene(titleScene);
      }

      exports.main = main;
    }, {}]
  }, {}, [1])(1);
});